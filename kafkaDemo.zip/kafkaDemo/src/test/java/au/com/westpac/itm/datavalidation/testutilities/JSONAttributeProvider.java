package au.com.westpac.itm.datavalidation.testutilities;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.com.westpac.itm.datavalidation.consumer.Receiver;
import au.com.westpac.itm.datavalidation.producer.Sender;
import au.com.westpac.itm.datavalidation.testconfig.TestConfig;

@Component
public class JSONAttributeProvider {
	@Autowired
	Receiver consumer;

	@Autowired
	Sender producer;

	@Autowired
	TestConfig testConfig;

	public String topicValue, fieldName;
	public boolean actualResult;

	void initializer()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		producer.producerLogic();
		CountDownLatch latch = new CountDownLatch(1);
		latch.await(10, TimeUnit.SECONDS);
		topicValue = consumer.consumerLogic();

	}

	String attribute_provider(String attriName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(topicValue);
		fieldName = (String) json.get(attriName);
		System.out.println("fieldName:::attribute_provider" + fieldName);
		return fieldName;

	}

	String attribute_provider2(String attriName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json1 = (JSONObject) parser.parse(topicValue);
		JSONObject json2 = (JSONObject) json1.get("evars");
		JSONObject json3 = (JSONObject) json2.get("evars");
		fieldName = (String) json3.get(attriName);
		System.out.println("fieldName:::attribute_provider2" + fieldName);
		return fieldName;

	}

	String attribute_provider3(String attriName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(topicValue);
		long longValue = (long) json.get(attriName);
		fieldName = Long.toString(longValue);
		System.out.println("fieldName:::attribute_provider3" + fieldName);
		return fieldName;
	}

	String attribute_provider4(String attriName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json1 = (JSONObject) parser.parse(topicValue);

		if (attriName.equalsIgnoreCase("exclude")) {
			JSONObject json2 = (JSONObject) json1.get(attriName);
			if (!json2.isEmpty()) {
				fieldName = "notNull";

			} else {
				fieldName = "Null";

			}
		} else if (attriName.equalsIgnoreCase("value")) {
			JSONObject json2 = (JSONObject) json1.get("exclude");
			fieldName = (String) json2.get(attriName);

		}

		System.out.println("fieldName:::attribute_provider4" + fieldName);

		return fieldName;

	}

	String attribute_provider5(String attriName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json1 = (JSONObject) parser.parse(topicValue);
		JSONObject json2 = (JSONObject) json1.get("props");
		fieldName = (String) json2.get(attriName);
		System.out.println("fieldName:::attribute_provider5" + fieldName);
		return fieldName;

	}

	String attribute_provider6(String attriName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(topicValue);
		boolean boolValue = (boolean) json.get(attriName);
		fieldName = String.valueOf(boolValue);
		System.out.println("fieldName:::attribute_provider" + fieldName);
		return fieldName;

	}

	String normalization_provider(String keyName) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(topicValue);
		if (json.containsKey(keyName)) {
			fieldName = (String) json.get(keyName);
		} else {
			fieldName = "No Such Key Available";
		}
		System.out.println("fieldName:::attribute_provider" + fieldName);
		return fieldName;

	}
}
