package au.com.westpac.itm.datavalidation.testconfig;

import org.springframework.stereotype.Component;

@Component
public class TestConfig {

	public String TESTDATA_FILEPATH = "C:\\Users\\Naveen.Arjunan\\OneDrive - EY\\Documents\\NaveenArjunan\\Westpac\\TestSuite\\Payloads\\testdata.xlsx";
	public String SHEETNAME_VALIDATION = "validation";
	public String SHEETNAME_STANDARDISATION = "standardisation";
	public String SHEETNAME_NORMALIZATION = "normalization";

}
