package au.com.westpac.itm.datavalidation.testutilities;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ValidationUtility {

	@Autowired
	JSONAttributeProvider dataProvider;

	// pageURL Attribute Logic
	public boolean pageURLTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		Pattern pattern = Pattern.compile("^(https)://");
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider("pageURL"));
		if (matcher.find() || dataProvider.attribute_provider("pageURL").equalsIgnoreCase("")
				|| dataProvider.attribute_provider("pageURL").equalsIgnoreCase("null")) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// pageName Attribute Logic wbc:banking:pay:transfer:funds
	public boolean pageNameTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		String regex = "^(wbc|bsa|stg|bom|bt)[a-zA-Z0-9: ]*(?<!:)$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider("pageName"));
		if (matcher.find()) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// eVar6 Attribute Logic
	public boolean eVar6TestExecutor(int testCase)
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		if (testCase == 1) {
			dataProvider.initializer();

			if (dataProvider.attribute_provider2("eVar6").equalsIgnoreCase("wbc")
					|| dataProvider.attribute_provider2("eVar6").equalsIgnoreCase("bsa")
					|| dataProvider.attribute_provider2("eVar6").equalsIgnoreCase("stg")
					|| dataProvider.attribute_provider2("eVar6").equalsIgnoreCase("bom")
					|| dataProvider.attribute_provider2("eVar6").equalsIgnoreCase("bt")) {

				dataProvider.actualResult = true;
			} else {

				dataProvider.actualResult = false;
			}

		} else if (testCase == 2) {
			dataProvider.initializer();
			if (dataProvider.attribute_provider2("eVar6") != "") {
				dataProvider.actualResult = true;
			} else {
				dataProvider.actualResult = false;
			}

		}

		return dataProvider.actualResult;

	}

	// eVar47 Attribute Logic
	public boolean eVar47TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		String string = dataProvider.attribute_provider2("eVar47");
		int count = 0;

		// Counts each character except space
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i) != ' ')
				count++;
		}

		if (dataProvider.attribute_provider2("eVar47") == ""
				|| dataProvider.attribute_provider2("eVar47").equalsIgnoreCase("")
				|| dataProvider.attribute_provider2("eVar47").equalsIgnoreCase("null") || count == 36) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// eVar48 Attribute Logic
	public boolean eVar48TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		String string = dataProvider.attribute_provider2("eVar48");
		int count = 0;

		// Counts each character except space
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i) != ' ')
				count++;
		}

		if (dataProvider.attribute_provider2("eVar48") == ""
				|| dataProvider.attribute_provider2("eVar48").equalsIgnoreCase("")
				|| dataProvider.attribute_provider2("eVar48").equalsIgnoreCase("null") || count == 36) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// userAgent Attribute Logic
	public boolean userAgentTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();

		if (dataProvider.attribute_provider("userAgent") == "" || dataProvider.attribute_provider("userAgent") != "") {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// referrer Attribute Logic
	public boolean referrerTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		Pattern pattern = Pattern.compile("^(https)://");
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider("referrer"));
		if (matcher.find()) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// visIdLow Attribute Logic
	public boolean visIdLowTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		if (dataProvider.attribute_provider("visIdLow") != "" || dataProvider.attribute_provider("visIdLow") != null) {

			dataProvider.actualResult = true;

		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;
	}

	// visIdHigh Attribute Logic
	public boolean visIdHighTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		if (dataProvider.attribute_provider("visIdHigh") != ""
				|| dataProvider.attribute_provider("visIdHigh") != null) {

			dataProvider.actualResult = true;

		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;
	}

	// eVar7 Attribute Logic needs look
	public boolean eVar7TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		if (dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("mob")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("mobile")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("mobapp")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("desktop")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("tab")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("tabapp")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("tablet")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("voice")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("watchapp")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("")
				|| dataProvider.attribute_provider2("eVar7").equalsIgnoreCase("null")) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// operatingSystem Attribute Logic
	public boolean operatingSystemTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();

		if (dataProvider.attribute_provider("operatingSystem").equalsIgnoreCase("")
				|| dataProvider.attribute_provider("operatingSystem").equalsIgnoreCase("null")
				|| dataProvider.attribute_provider("operatingSystem") != "") {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// browser Attribute Logic
	public boolean browserTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();

		if (dataProvider.attribute_provider("browser").equalsIgnoreCase("")
				|| dataProvider.attribute_provider("browser").equalsIgnoreCase("null")
				|| dataProvider.attribute_provider("browser") != "") {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// exclude Attribute Logic
	public boolean excludeTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		if (dataProvider.attribute_provider4("exclude").equalsIgnoreCase("notNull")) {

			dataProvider.actualResult = true;

		} else {
			dataProvider.actualResult = false;
		}
		return dataProvider.actualResult;

	}

	// hitSource Attribute Logic
	public boolean hitSourceTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		if (dataProvider.attribute_provider("hitSource") != ""
				|| dataProvider.attribute_provider("hitSource") != null) {

			dataProvider.actualResult = true;

		} else {
			dataProvider.actualResult = false;
		}
		return dataProvider.actualResult;

	}

	// prop23 Attribute Logic
	public boolean prop23TestExecutor(int testCase)
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		if (testCase == 1) {
			dataProvider.initializer();
			Pattern pattern = Pattern.compile("^[^:].*[^:]$");
			Matcher matcher = pattern.matcher(dataProvider.attribute_provider5("prop23"));
			if (matcher.find())
				dataProvider.actualResult = true;
			else
				dataProvider.actualResult = false;

		} else if (testCase == 2) {
			dataProvider.initializer();
			Pattern pattern = Pattern.compile("^(wbc|bsa|stg|bom|bt)");
			Matcher matcher = pattern.matcher(dataProvider.attribute_provider5("prop23"));
			if (matcher.find())
				dataProvider.actualResult = true;
			else
				dataProvider.actualResult = false;
		} else if (testCase == 3) {
			dataProvider.initializer();

			if (dataProvider.attribute_provider5("prop23").equalsIgnoreCase("")
					|| dataProvider.attribute_provider5("prop23").equalsIgnoreCase("null")) {
				dataProvider.actualResult = false;
			} else {
				dataProvider.actualResult = true;
			}

		}
		return dataProvider.actualResult;

	}

	// eVar35 Attribute Logic

	public boolean eVar35TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		dataProvider.initializer();
		String string = dataProvider.attribute_provider2("eVar35");
		int count = 0;

		// Counts each character except space
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i) != ' ')
				count++;
		}

		if (dataProvider.attribute_provider2("eVar35").equalsIgnoreCase("")
				|| dataProvider.attribute_provider2("eVar35").equalsIgnoreCase("null") || count == 36) {
			dataProvider.actualResult = true;
		} else {
			dataProvider.actualResult = false;
		}

		return dataProvider.actualResult;

	}

	// eVar3 Attribute Logic
	public boolean eVar3TestExecutor(int testCase)
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		if (testCase == 1) {
			dataProvider.initializer();
			Pattern pattern = Pattern.compile("^[^:].*[^:]$");
			Matcher matcher = pattern.matcher(dataProvider.attribute_provider2("eVar3"));
			if (matcher.find())
				dataProvider.actualResult = true;
			else
				dataProvider.actualResult = false;

		} else if (testCase == 2) {
			dataProvider.initializer();
			Pattern pattern = Pattern.compile("^(wbc|bsa|stg|bom|bt)");
			Matcher matcher = pattern.matcher(dataProvider.attribute_provider2("eVar3"));
			if (matcher.find())
				dataProvider.actualResult = true;
			else
				dataProvider.actualResult = false;
		} else if (testCase == 3) {
			dataProvider.initializer();
			if (dataProvider.attribute_provider2("eVar3").equalsIgnoreCase("")
					|| dataProvider.attribute_provider2("eVar3").equalsIgnoreCase("null")
					|| dataProvider.attribute_provider2("eVar3") != null
					|| dataProvider.attribute_provider2("eVar3") != "") {

				dataProvider.actualResult = true;
			} else {
				dataProvider.actualResult = false;
			}

		}
		return dataProvider.actualResult;

	}

	// prop15 Attribute Logic
	public boolean prop15TestExecutor(int testCase)
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		if (testCase == 1) {
			dataProvider.initializer();
			Pattern pattern = Pattern.compile("^[^:].*[^:]$");
			Matcher matcher = pattern.matcher(dataProvider.attribute_provider5("prop15"));
			if (matcher.find())
				dataProvider.actualResult = true;
			else
				dataProvider.actualResult = false;

		} else if (testCase == 2) {
			dataProvider.initializer();
			Pattern pattern = Pattern.compile("^(wbc|bsa|stg|bom|bt)");
			Matcher matcher = pattern.matcher(dataProvider.attribute_provider5("prop15"));
			if (matcher.find())
				dataProvider.actualResult = true;
			else
				dataProvider.actualResult = false;
		} else if (testCase == 3) {
			dataProvider.initializer();
			if (dataProvider.attribute_provider5("prop15").equalsIgnoreCase("")
					|| dataProvider.attribute_provider5("prop15").equalsIgnoreCase("null")
					|| dataProvider.attribute_provider5("prop15") != null
					|| dataProvider.attribute_provider5("prop15") != "") {
				dataProvider.actualResult = true;
			} else {
				dataProvider.actualResult = false;
			}

		}
		return dataProvider.actualResult;

	}

	// eVar40 Attribute Logic
	public boolean eVar40TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		if (dataProvider.attribute_provider2("eVar40").equalsIgnoreCase("logged in")
				|| dataProvider.attribute_provider2("eVar40").equalsIgnoreCase("logged out")
				|| dataProvider.attribute_provider2("eVar40").equalsIgnoreCase("")
				|| dataProvider.attribute_provider2("eVar40").equalsIgnoreCase("null"))
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;

		return dataProvider.actualResult;

	}

	// prop52 Attribute Logic
	public boolean prop52TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		Pattern pattern = Pattern.compile("^[^:].*[^:]$");
		Matcher matcher = pattern.matcher(dataProvider.attribute_provider5("prop52"));
		if (matcher.find() && dataProvider.attribute_provider5("prop52") != null)
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;

		return dataProvider.actualResult;

	}

	// ip Attribute Logic
	public boolean ipTestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		if (dataProvider.attribute_provider("ip").equalsIgnoreCase("")
				|| dataProvider.attribute_provider("ip").equalsIgnoreCase("null")
				|| dataProvider.attribute_provider("ip") != null)
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;

		return dataProvider.actualResult;

	}

	// prop7 Attribute Logic
	public boolean prop7TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		if (dataProvider.attribute_provider5("prop7").equalsIgnoreCase("")
				|| dataProvider.attribute_provider5("prop7").equalsIgnoreCase("null")
				|| dataProvider.attribute_provider5("prop7") != null)
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;

		return dataProvider.actualResult;

	}

	// prop40 Attribute Logic
	public boolean prop40TestExecutor()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {

		dataProvider.initializer();
		if (dataProvider.attribute_provider5("prop40").equalsIgnoreCase("pub")
				|| dataProvider.attribute_provider5("prop40").equalsIgnoreCase("auth")
				|| dataProvider.attribute_provider5("prop40").equalsIgnoreCase("")
				|| dataProvider.attribute_provider5("prop40").equalsIgnoreCase("null"))
			dataProvider.actualResult = true;
		else
			dataProvider.actualResult = false;

		return dataProvider.actualResult;

	}
}
