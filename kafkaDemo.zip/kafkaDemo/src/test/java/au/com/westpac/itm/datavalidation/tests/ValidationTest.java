package au.com.westpac.itm.datavalidation.tests;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import au.com.westpac.itm.datavalidation.testconfig.TestConfig;
import au.com.westpac.itm.datavalidation.testutilities.JSONAttributeProvider;
import au.com.westpac.itm.datavalidation.testutilities.ValidationUtility;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Step;
import io.qameta.allure.Story;

@SpringBootTest

public class ValidationTest extends AbstractTestNGSpringContextTests {
	@Autowired
	JSONAttributeProvider dataProvider;

	@Autowired
	ValidationUtility validationUtility;

	@Autowired
	TestConfig testConfig;

	@BeforeTest
	void setUp() throws ParseException, IOException {
		System.out.println("::: Validation Testing Starts:::");

	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PageURL")
	@Step("pageURL attribute should be starts with https:// or can be NULL")
	@Severity(SeverityLevel.MINOR)
	@Description("pageURL attribute should be starts with https:// can be NULL")
	@Test(priority = 1, description = "PageURL should be starts with https:// or can be NULL")
	void pageURLStartsWith()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.pageURLTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PageName")
	@Step("PageName Verification")
	@Severity(SeverityLevel.MINOR)
	@Description("pageName Attribute shouldn't starts or ends with : and can starts anyone of the following wbc|bsa|stg|bom|bt acronyms and : as permissible symbol and shouldn't not null")
	@Test(priority = 2, description = "PageName verification")
	void pageNameValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.pageNameTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);

	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR6")
	@Step("eVar6 attribute contains “wbc”, “bsa”, “stg”, “bom”, “bt”")
	@Severity(SeverityLevel.MINOR)
	@Description("eVar6 attribute contains “wbc”, “bsa”, “stg”, “bom”, “bt”")
	@Test(priority = 3, description = "EVAR6 attribute contains “wbc”, “bsa”, “stg”, “bom”, “bt”")
	void eVar6Contains()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar6TestExecutor(1);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR6")
	@Step("eVar6 attribute can not be null")
	@Severity(SeverityLevel.MINOR)
	@Description("eVar6 attribute can not be null")
	@Test(priority = 4, description = "EVAR6 attribute can not be null")
	void eVar6CannotNull()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar6TestExecutor(2);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR47")
	@Step("eVar47 attribute can be null or characters shoulde be less than equal to 36")
	@Severity(SeverityLevel.MINOR)
	@Description("eVar47 attribute can be null or characters shoulde be less than equal to 36")
	@Test(priority = 5, description = "EVAR47 attribute can be null or characters shoulde be less than equal to 36")
	void eVar47Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar47TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR48")
	@Step("eVar48 attribute can be null or characters shoulde be less than equal to 36")
	@Severity(SeverityLevel.MINOR)
	@Description("eVar48 attribute can be null or characters shoulde be less than equal to 36")
	@Test(priority = 6, description = "EVAR48 attribute can be null or characters shoulde be less than equal to 36")
	void eVar48Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar48TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_UserAgent")
	@Step("userAgent attribute can be null or not")
	@Severity(SeverityLevel.MINOR)
	@Description("userAgent attribute can be null or not")
	@Test(priority = 7, description = "UserAgent attribute can be null or not")
	void userAgentValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.userAgentTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_Referrer")
	@Step("referrer attribute should starts with https://")
	@Severity(SeverityLevel.MINOR)
	@Description("referrer attribute should starts with https://")
	@Test(priority = 8, description = "Referrer attribute should starts with https://")
	void referrerVaidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.referrerTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_VISIDLOW")
	@Step("visIdLow attribute can not be null")
	@Severity(SeverityLevel.MINOR)
	@Description("visIdLow attribute can not be null")
	@Test(priority = 9, description = "VISIDLOW attribute can not be null")
	void visIdLowVaidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.visIdLowTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_VISIDHIGH")
	@Step("visIdHigh can not be null")
	@Description("visIdHigh attribute can not be null")
	@Test(priority = 10, description = "VISIDHIGH can not be null")
	void visIdHighVaidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.visIdHighTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR7")
	@Step("eVar7 can Contains “mob”, “mobile”, “mobapp”, “desktop”, “tab”, “tabapp”, “tablet”, “voice”, “watchapp” Can be null")
	@Description("eVar7 can Contains “mob”, “mobile”, “mobapp”, “desktop”, “tab”, “tabapp”, “tablet”, “voice”, “watchapp” Can be null")
	@Test(priority = 11, description = "EVAR7 can Contains “mob”, “mobile”, “mobapp”, “desktop”, “tab”, “tabapp”, “tablet”, “voice”, “watchapp” Can be null")
	void eVar7Vaidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar7TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_OS")
	@Step("operatingSystem can not be null")
	@Description("operatingSystem can not be null")
	@Test(priority = 12, description = "Operating System attribute can be null")
	void operatingSystemValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.operatingSystemTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_Browser")
	@Step("browser attribute can be null")
	@Description("browser attribute can be null")
	@Test(priority = 13, description = "Browser attribute can be null")
	void browserValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.browserTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_Exclude")
	@Step("exclude attribute can not be null")
	@Severity(SeverityLevel.MINOR)
	@Description("exclude attribute can not be null")
	@Test(priority = 14, description = "Exclude attribute can not be null")
	void excludeValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.excludeTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_HitSource")
	@Step("hitSource attribute can not be null")
	@Description("hitSource attribute can not be null")
	@Test(priority = 15, description = "HitSource attribute can not be null")
	void hitSourceValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.hitSourceTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP23")
	@Step("prop23 attribute can not start and end with :")
	@Description("prop23 attribute can not start and end with :")
	@Test(priority = 16, description = "PROP23 attribute can not start and end with :")
	void prop23Validation1()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop23TestExecutor(1);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP23")
	@Step("prop23 attribute can Starts with “wbc”, “bsa”, “stg”, “bom”, “bt")
	@Description("prop23 attribute can Starts with “wbc”, “bsa”, “stg”, “bom”, “bt")
	@Test(priority = 17, description = "PROP23 attribute can Starts with “wbc”, “bsa”, “stg”, “bom”, “bt")
	void prop23Validation2()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop23TestExecutor(2);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP23")
	@Step("prop23 attribute can be NULL")
	@Description("prop23 attribute can be NULL")
	@Test(priority = 18, description = "PROP23 attribute can be NULL")
	void prop23Validation3()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop23TestExecutor(3);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Description("eVar35 attribute can be null or 36 characters")
	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR35")
	@Step("eVar35 attribute can be null or 36 characters")
	@Test(priority = 19, description = "EVAR35 attribute can be null or 36 characters")
	void eVar35Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar35TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR3")
	@Step("eVar3 attribute can not starts and ends with :")
	@Description("eVar3 attribute can not starts and ends with :")
	@Test(priority = 20, description = "EVAR3 attribute can not starts and ends with :")
	void eVar3Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar3TestExecutor(1);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR3")
	@Step("eVar3 attribute starts with “wbc”, “bsa”, “stg”, “bom”, “bt”")
	@Description("eVar3 attribute starts with “wbc”, “bsa”, “stg”, “bom”, “bt”")
	@Test(priority = 21, description = "EVAR3 attribute starts with “wbc”, “bsa”, “stg”, “bom”, “bt”")
	void eVar3Validation2()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar3TestExecutor(2);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR3")
	@Step("eVar3 attributr can  be null")
	@Description("eVar3 attributr can  be null")
	@Test(priority = 22, description = "EVAR3 attributr can  be null")
	void eVar3Validation3()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar3TestExecutor(3);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP15")
	@Step("prop15 attribute can not starts and ends with :")
	@Description("prop15 attribute can not starts and ends with :")
	@Test(priority = 23, description = "PROP15 attribute can not starts and ends with :")
	void prop15Validation1()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop15TestExecutor(1);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP15")
	@Step("prop15 attribute starts with “wbc”, “bsa”, “stg”, “bom”, “bt”")
	@Description("prop15 attribute starts with “wbc”, “bsa”, “stg”, “bom”, “bt”")
	@Test(priority = 24, description = "PROP15 attribute starts with “wbc”, “bsa”, “stg”, “bom”, “bt”")
	void prop15Validation2()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop15TestExecutor(2);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP15")
	@Step("prop15 attribute can  be null")
	@Description("prop15 attribute can  be null")
	@Test(priority = 25, description = "PROP15 attribute can  be null")
	void prop15Validation3()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop15TestExecutor(3);
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_EVAR40")
	@Step("eVar40 attribute an be “logged in” or “logged out”  and can be null")
	@Description("eVar40 attribute an be “logged in” or “logged out”  and can be null ")
	@Test(priority = 26, description = "EVAR40 attribute an be “logged in” or “logged out” and can be null ")
	void evar40Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.eVar40TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP52")
	@Step("prop52 attribute cannot start or end with “:” and can not be null")
	@Description("prop52 attribute cannot start or end with “:” and can not be null")
	@Test(priority = 27, description = "PROP52 attribute cannot start or end with “:” and can not be null")
	void prop52Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop52TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_IP")
	@Step("ip attribute can  be null")
	@Description("ip attribute can  be null")
	@Test(priority = 28, description = "IP attribute can  be null")
	void ipValidation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.ipTestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP7")
	@Step("prop7 attribute can be null")
	@Severity(SeverityLevel.MINOR)
	@Description("prop7 attribute can be null")
	@Test(priority = 29, description = "PROP7 attribute can be null")
	void prop7Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop7TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@Epic("DataPipeline")
	@Feature("Validation")
	@Story("TC_Val_PROP40")
	@Step("prop40 attribute can be “pub” or “auth” or null")
	@Severity(SeverityLevel.MINOR)
	@Description("prop40 attribute can be “pub” or “auth” or null")
	@Test(priority = 30, description = "PROP40 attribute can be “pub” or “auth” or null")
	void prop40Validation()
			throws ParseException, IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		validationUtility.prop40TestExecutor();
		Assert.assertEquals(dataProvider.actualResult, true);
	}

	@AfterTest
	void finishTest() {
		System.out.println(":::Validation Test Finished:::");
	}
}
