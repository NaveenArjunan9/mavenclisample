package au.com.westpac.itm.datavalidation.producer;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

@Component
public class Sender {

	private static final Logger LOGGER = LoggerFactory.getLogger(Sender.class);

	@Autowired
	private KafkaTemplate<byte[], byte[]> kafkaTemplate;

	public void producerLogic() throws IOException, InterruptedException, ExecutionException {
		// configLogic();
		eventLogic();

	}

	public void eventLogic() throws IOException, InterruptedException, ExecutionException {
		File jsonFile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "QualifiedEvent.json");
		File schemafile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "QualifiedEvent.avsc");

		String jsonObj = new String(Files.readAllBytes(jsonFile.toPath()));
		String schemaObj = new String(Files.readAllBytes(schemafile.toPath()));
		JsonAvroConverter converter = new JsonAvroConverter();
		// conversion tobinary Avro
		byte[] binaryAvroEvent = converter.convertToAvro(jsonObj.getBytes(), schemaObj);
		System.out.println(":::avro:::" + new String(binaryAvroEvent));
		LOGGER.info("sender user='{}'", binaryAvroEvent);

		kafkaTemplate.send("ev-app-a00ad3-dpvalidationingress-1", binaryAvroEvent).get();

	}

}
