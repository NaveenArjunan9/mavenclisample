package au.com.westpac.itm.datavalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DataValidationApp {

	public static void main(String[] args) {
		SpringApplication.run(DataValidationApp.class, args);
	}

}
